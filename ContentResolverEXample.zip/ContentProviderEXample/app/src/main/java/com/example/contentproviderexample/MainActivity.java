package com.example.contentproviderexample;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = findViewById(R.id.txt);

        try {
            Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
            String[] projection = new String[]{
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,

            };

            String selection = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY + "='Avesh'";

            ContentResolver resolver = getContentResolver();


            Cursor res = resolver.query(uri,projection,selection,null,null);
            res.moveToNext();
            if(res.getCount()==0){
                Toast.makeText(this,"Records not found.",Toast.LENGTH_SHORT).show();
            }
            else{
                txt.setText("Name="+res.getString(0) + ": phone=" +res.getString(1));
            }

        }
        catch (Exception e){
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }



    }
}