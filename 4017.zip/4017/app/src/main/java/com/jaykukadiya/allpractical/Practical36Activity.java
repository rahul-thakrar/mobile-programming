package com.jaykukadiya.allpractical;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical36Activity extends AppCompatActivity {

    private AnimationDrawable animation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical36);
        ImageView frames = findViewById(R.id.frames);
        frames.setImageResource(R.drawable.frame_animation_list);
        animation = (AnimationDrawable) frames.getDrawable();
        Button start = findViewById(R.id.start);
        Button stop = findViewById(R.id.stop);
        start.setOnClickListener(v -> animation.start());
        stop.setOnClickListener(v -> animation.stop());
    }
}
