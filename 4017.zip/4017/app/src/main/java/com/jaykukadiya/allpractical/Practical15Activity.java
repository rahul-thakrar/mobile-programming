package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Practical15Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical15);
        CheckBox cb1 = findViewById(R.id.cb_java);
        CheckBox cb2 = findViewById(R.id.cb_kotlin);
        CheckBox cb3 = findViewById(R.id.cb_cpp);
        TextView summary = findViewById(R.id.summary);
        CompoundButton.OnCheckedChangeListener listener = (buttonView, isChecked) ->
                summary.setText(buildSummary(cb1.isChecked(), cb2.isChecked(), cb3.isChecked()));
        cb1.setOnCheckedChangeListener(listener);
        cb2.setOnCheckedChangeListener(listener);
        cb3.setOnCheckedChangeListener(listener);
        summary.setText(buildSummary(cb1.isChecked(), cb2.isChecked(), cb3.isChecked()));
    }

    private static String buildSummary(boolean j, boolean k, boolean c) {
        StringBuilder b = new StringBuilder("Selected: ");
        if (j) {
            b.append("Java ");
        }
        if (k) {
            b.append("Kotlin ");
        }
        if (c) {
            b.append("C++ ");
        }
        if (!j && !k && !c) {
            b.append("(none)");
        }
        return b.toString().trim();
    }
}
