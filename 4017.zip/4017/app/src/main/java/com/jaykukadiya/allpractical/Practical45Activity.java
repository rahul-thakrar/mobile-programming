package com.jaykukadiya.allpractical;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Practical45Activity extends AppCompatActivity {

    private static final int REQ_CONTACTS = 4500;
    private List<Map<String, String>> rows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical45);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS);
        } else {
            loadContacts();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CONTACTS && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadContacts();
        }
    }

    private void loadContacts() {
        rows.clear();
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] proj = new String[]{
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
        };
        try (Cursor c = getContentResolver().query(uri, proj, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String name = c.getString(0);
                    String num = c.getString(1);
                    Map<String, String> m = new HashMap<>();
                    m.put("name", name);
                    m.put("number", num);
                    rows.add(m);
                }
            }
        }
        ListView list = findViewById(R.id.contacts);
        list.setAdapter(new SimpleAdapter(this, rows,
                android.R.layout.simple_list_item_2,
                new String[]{"name", "number"},
                new int[]{android.R.id.text1, android.R.id.text2}));
        list.setOnItemClickListener((parent, view, position, id) -> {
            String tel = rows.get(position).get("number");
            if (tel == null || tel.isEmpty()) {
                Toast.makeText(this, "No number", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(tel)));
            startActivity(dial);
        });
    }
}
