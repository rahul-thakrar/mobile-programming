package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;

public class CountryDetailFragment extends Fragment {

    private static final String ARG_NAME = "name";
    private static final String ARG_FLAG_URL = "flag_url";

    public static CountryDetailFragment newInstance(String name, @Nullable String flagImageUrl) {
        CountryDetailFragment f = new CountryDetailFragment();
        Bundle b = new Bundle();
        b.putString(ARG_NAME, name);
        b.putString(ARG_FLAG_URL, flagImageUrl);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_country_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Bundle b = getArguments();
        if (b == null) {
            return;
        }
        String name = b.getString(ARG_NAME, "");
        String flagUrl = b.getString(ARG_FLAG_URL);
        TextView title = view.findViewById(R.id.country_name);
        ImageView img = view.findViewById(R.id.flag);
        title.setText(name);
        if (!TextUtils.isEmpty(flagUrl)) {
            img.setVisibility(View.VISIBLE);
            Glide.with(this)
                    .load(flagUrl)
                    .fitCenter()
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_menu_report_image)
                    .into(img);
        } else {
            Glide.with(this).clear(img);
            img.setVisibility(View.INVISIBLE);
        }
    }
}
