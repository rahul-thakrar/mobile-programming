package com.jaykukadiya.allpractical;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class Practical24Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical24);
        TextView label = findViewById(R.id.time_label);
        Button pick = findViewById(R.id.pick_time);
        Calendar cal = Calendar.getInstance();
        pick.setOnClickListener(v -> new TimePickerDialog(this, (view, hourOfDay, minute) -> {
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, hourOfDay);
            c.set(Calendar.MINUTE, minute);
            label.setText(DateFormat.format("HH:mm", c));
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show());
    }
}
