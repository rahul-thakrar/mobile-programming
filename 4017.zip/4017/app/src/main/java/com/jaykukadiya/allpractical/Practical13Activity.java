package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical13Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical13);
        ListView list = findViewById(R.id.list);
        String[] items = {"Alpha", "Beta", "Gamma", "Delta"};
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items));
        list.setOnItemClickListener((parent, view, position, id) ->
                Toast.makeText(this, items[position], Toast.LENGTH_SHORT).show());
    }
}
