package com.example.tweenanimation;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    Button b_alpha, b_rotate, b_scale,b_trans,b_frame;
    TextView txt;
    ImageView img;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        b_alpha = findViewById(R.id.b_alpha);
        b_rotate = findViewById(R.id.b_rotation);
        b_scale=findViewById(R.id.b_scale);
        b_trans=findViewById(R.id.b_translate);
        txt=findViewById(R.id.txt);
        b_frame=findViewById(R.id.b_frame);
        img=findViewById(R.id.imageView);

        b_alpha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.alpha);
                txt.startAnimation(animation);
            }
        });

        b_rotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.rotate);
                txt.startAnimation(animation);
            }
        });

        b_scale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.scale);
                txt.startAnimation(animation);
            }
        });

        b_trans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.translate);
                txt.startAnimation(animation);
            }
        });

        b_frame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


    }
}